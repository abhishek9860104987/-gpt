import React from 'react';

const App: React.FC = () => {
  return (
    <div style={{ fontFamily: 'sans-serif', height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header style={{ padding: '1rem', borderBottom: '1px solid #eee', fontWeight: 'bold' }}>
        AI Chat Assistant
      </header>
      <main style={{ flex: 1, overflow: 'auto', padding: '1rem' }}>
        {/* Chat messages will go here */}
        <div style={{ color: '#888' }}>Chat UI coming soon...</div>
      </main>
      <footer style={{ padding: '1rem', borderTop: '1px solid #eee' }}>
        {/* Input box will go here */}
        <input style={{ width: '100%', padding: '0.5rem' }} placeholder="Type a message..." />
      </footer>
    </div>
  );
};

export default App; 