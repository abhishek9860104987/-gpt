import * as vscode from 'vscode';
import * as path from 'path';

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand('aiChat.openChat', () => {
      const panel = vscode.window.createWebviewPanel(
        'aiChat',
        'AI Chat Assistant',
        vscode.ViewColumn.Beside,
        {
          enableScripts: true,
          localResourceRoots: [
            vscode.Uri.file(path.join(context.extensionPath, 'media')),
            vscode.Uri.file(vscode.workspace.rootPath || ''),
          ],
        }
      );

      const scriptPath = vscode.Uri.file(
        path.join(context.extensionPath, 'media', 'main.js')
      );
      const scriptUri = panel.webview.asWebviewUri(scriptPath);

      panel.webview.html = getWebviewContent(scriptUri);

      // Handle messages from the webview
      panel.webview.onDidReceiveMessage(async (message: any) => {
        if (message.type === 'getWorkspaceFiles') {
          // List files in workspace for @ mention
          const files = await vscode.workspace.findFiles('**/*');
          panel.webview.postMessage({ type: 'workspaceFiles', files: files.map((f: vscode.Uri) => f.fsPath) });
        }
        // Add more message handlers (e.g., for AI requests, file reads, etc.)
      });
    })
  );
}

function getWebviewContent(scriptUri: vscode.Uri) {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>AI Chat Assistant</title>
    </head>
    <body>
      <div id="root"></div>
      <script src="${scriptUri}"></script>
    </body>
    </html>
  `;
}

export function deactivate() {} 