# VS Code AI Chat Assistant

A Visual Studio Code extension with a React-based AI chat assistant. Supports file/image attachments via `@filename` mentions and AI-powered code generation using OpenAI API.

## Features
- React chat UI in a VS Code WebView
- Markdown and code block rendering
- File/image attachment with `@filename` syntax
- AI code generation (OpenAI API)

## Setup

1. **Install dependencies:**
   ```bash
   npm install
   ```
2. **Build the extension and React app:**
   ```bash
   npm run build
   ```
3. **Launch in VS Code:**
   - Press `F5` in VS Code to open a new Extension Development Host.
   - Run the command `Open AI Chat Assistant` from the Command Palette.

## Development
- `npm run watch` — Watch and rebuild on changes.
- Source code:
  - Extension: `src/extension.ts`
  - React UI: `src/webview/`

## Configuration
- Set your OpenAI API key in the extension settings or via environment variable (to be implemented).

## Demo
Share a demo video and your GitHub ID/phone as requested in the assignment. 